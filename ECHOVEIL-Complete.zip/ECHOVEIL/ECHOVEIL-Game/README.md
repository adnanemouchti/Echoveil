# ECHOVEIL: The Game

Single-player dark fantasy card-battle game that runs in the browser. Plain HTML, CSS and JavaScript; no engine, no build step, no dependencies.

## Features (as implemented)

80 original cards (Monsters, Miracles, Traps), battle arena, AI opponents with adjustable IQ (Echo Initiate to Echo Sovereign), four-quest campaign, deck builder (20-40 cards), 22 achievements, and settings. Progress is saved automatically in the browser (`localStorage`, key `echo`).

## Structure

```
index.html            Screens: main menu, campaign/challenge, deck builder, battle arena
css/style.css         All styles
js/assets.js          Image paths: CIMG (card thumbnails, indexed by card id) and BTN (summon buttons)
js/game.js            All game code: card definitions and stats, rules, AI, campaign, achievements, UI, sound effects
assets/cards/         80 card thumbnails (file names follow the website's card numbering)
assets/backgrounds/   Menu art, battlefield board, arena art
assets/ui/            Summon ATK / Summon DEF / Set face-down button art
```

Card data and gameplay systems live together in `js/game.js`. Sound effects are generated in code with the Web Audio API, so there are no audio files.

## Launch

```bash
python3 -m http.server 8001
# open http://localhost:8001
```

## Test

There is no automated test suite. Test by hand: start a duel, summon (with tributes for Level 5+), attack, set and trigger a Trap, play a Miracle, finish a duel, check that progress persists after a reload, and open the deck builder. Check the browser console for errors.

## Develop

Edit `js/game.js` and reload. After changes, copy this folder into `ECHOVEIL-Website/game/` (use `ECHOVEIL-Website/tools/sync-game.sh`) so the website's Play page uses the new build.

## Known gaps

- The game was exported from a packed single-file build; the original separate source files were not available. The structure above is a faithful split of that build, not the original repository layout.
- Fonts (Cinzel) load from Google Fonts.
