# ECHOVEIL: Official Website

Static website for ECHOVEIL, a single-player dark fantasy card-battle game. Plain HTML, CSS and JavaScript; nothing to install.

## Structure

```
index.html            All pages (single-page app, hash routes: #home, #the-game, #cards, #lore, #gallery, #play, #store)
css/styles.css        All styles
js/assets.js          Image path resolver (data-img attributes)
js/config.js          Optional links: wishlistUrl, supportUrl, socials, platforms (empty by default)
js/cards-data.js      The 80 cards (name, type, rarity, stats, image path)
js/card-lore.js       Proposed lore for cards
js/ui.js              Reveal-on-scroll, hero effects, modals
js/cards-page.js      Cards page: search, filters, card viewer
js/gallery.js         Gallery page and lightbox
js/play.js            Play page: loads the game in an iframe (game/index.html)
js/links.js           Wires config links to the Wishlist/Support buttons
js/router.js          Hash router and active navigation state
assets/images/        Logo, backgrounds, concept art, gameplay screenshots, all 80 card images
game/                 Copy of ECHOVEIL-Game (what the Play page loads)
tools/sync-game.sh    Refresh game/ from ../ECHOVEIL-Game
```

## Run locally

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

## Deploy to GitHub Pages

Push the contents of this folder to a repository, then **Settings > Pages > Deploy from a branch > main / root**. `.nojekyll` is included so Pages serves every file as-is.

## Edit

- Add real links in `js/config.js` to enable the Wishlist, Support and social buttons. Leave them empty until real pages exist.
- Card data lives in `js/cards-data.js`; images are referenced by path under `assets/images/cards/`.
- Lore text (Echoes, Factions, Timeline, Locations) is in the Lore section of `index.html`. New lore is marked "Proposed" until you approve it.
- Official logo: `assets/images/brand/echoveil-logo.png`, used in the header, hero and footer.

## Known gaps

- Fonts load from Google Fonts (not bundled).
- No official faction artwork exists yet (emblems on the Factions tab are simple placeholders), and the Ruined Sanctum and Eclipse Gate location images are low resolution.
- The Gallery has a video placeholder; no trailer has been supplied.
