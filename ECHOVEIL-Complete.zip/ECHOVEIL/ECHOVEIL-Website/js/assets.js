/* Image path resolver. All images are real files under assets/images/.
   IMGMAP can map a path to a different URL if ever needed. */
const IMGMAP={};
const IMGS=p=>IMGMAP[p]||(p?new URL(p,document.baseURI).href:p);
document.querySelectorAll('[data-img]').forEach(e=>e.src=IMGS(e.dataset.img));
document.querySelectorAll('[data-pbg]').forEach(e=>e.style.setProperty('--pbg','url('+IMGS(e.dataset.pbg)+')'));
document.documentElement.style.setProperty('--cover','url('+IMGS('assets/images/gameplay/duel-start.jpg')+')');
