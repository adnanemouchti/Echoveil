/* ECHOVEIL card data, extracted from the game. Rarity follows the game's own rar() rule. */
window.ECHOVEIL_CARDS = [
 {
  "id": 1,
  "name": "Ember Imp",
  "type": "monster",
  "rarity": "common",
  "img": "assets/images/cards/monsters/01-ember-imp.jpg",
  "level": 1,
  "atk": 500,
  "def": 400,
  "tributes": 0
 },
 {
  "id": 2,
  "name": "Thorn Hound",
  "type": "monster",
  "rarity": "common",
  "img": "assets/images/cards/monsters/02-thorn-hound.jpg",
  "level": 1,
  "atk": 600,
  "def": 600,
  "tributes": 0
 },
 {
  "id": 3,
  "name": "Glass Sprite",
  "type": "monster",
  "rarity": "common",
  "img": "assets/images/cards/monsters/03-glass-sprite.jpg",
  "level": 2,
  "atk": 800,
  "def": 600,
  "tributes": 0
 },
 {
  "id": 4,
  "name": "Hollow Rat",
  "type": "monster",
  "rarity": "common",
  "img": "assets/images/cards/monsters/04-hollow-rat.jpg",
  "level": 2,
  "atk": 700,
  "def": 900,
  "tributes": 0
 },
 {
  "id": 5,
  "name": "Void Moth",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/05-void-moth.jpg",
  "level": 3,
  "atk": 1000,
  "def": 1000,
  "tributes": 0
 },
 {
  "id": 6,
  "name": "Iron Warden",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/06-iron-warden.jpg",
  "level": 3,
  "atk": 1100,
  "def": 900,
  "tributes": 0
 },
 {
  "id": 7,
  "name": "Mire Sludge",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/07-mire-sludge.jpg",
  "level": 3,
  "atk": 1200,
  "def": 1000,
  "tributes": 0
 },
 {
  "id": 8,
  "name": "Clockling",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/08-clockling.jpg",
  "level": 4,
  "atk": 1300,
  "def": 900,
  "tributes": 0
 },
 {
  "id": 9,
  "name": "Ash Wraith",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/09-ash-wraith.jpg",
  "level": 4,
  "atk": 1300,
  "def": 1200,
  "tributes": 0
 },
 {
  "id": 10,
  "name": "Stone Sentinel",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/10-stone-sentinel.jpg",
  "level": 3,
  "atk": 1200,
  "def": 1100,
  "tributes": 0
 },
 {
  "id": 11,
  "name": "Shade Lurker",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/11-shade-lurker.jpg",
  "level": 4,
  "atk": 1400,
  "def": 1000,
  "tributes": 0
 },
 {
  "id": 12,
  "name": "Crimson Leech",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/12-crimson-leech.jpg",
  "level": 3,
  "atk": 1200,
  "def": 800,
  "tributes": 0
 },
 {
  "id": 13,
  "name": "Frost Stag",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/13-frost-stag.jpg",
  "level": 4,
  "atk": 1400,
  "def": 1000,
  "tributes": 0
 },
 {
  "id": 14,
  "name": "Mire Bishop",
  "type": "monster",
  "rarity": "uncommon",
  "img": "assets/images/cards/monsters/14-mire-bishop.jpg",
  "level": 4,
  "atk": 1500,
  "def": 1200,
  "tributes": 0
 },
 {
  "id": 15,
  "name": "Void Hound",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/15-void-hound.jpg",
  "level": 5,
  "atk": 1600,
  "def": 1500,
  "tributes": 1
 },
 {
  "id": 16,
  "name": "Storm Harpy",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/16-storm-harpy.jpg",
  "level": 5,
  "atk": 1600,
  "def": 1400,
  "tributes": 1
 },
 {
  "id": 17,
  "name": "Bone Marionette",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/17-bone-marionette.jpg",
  "level": 5,
  "atk": 1600,
  "def": 1300,
  "tributes": 1
 },
 {
  "id": 18,
  "name": "Lumen Steed",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/18-lumen-steed.jpg",
  "level": 5,
  "atk": 1700,
  "def": 1200,
  "tributes": 1
 },
 {
  "id": 19,
  "name": "Crystal Colossus",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/19-crystal-colossus.jpg",
  "level": 5,
  "atk": 1800,
  "def": 1600,
  "tributes": 1
 },
 {
  "id": 20,
  "name": "Dusk Assassin",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/20-dusk-assassin.jpg",
  "level": 5,
  "atk": 1800,
  "def": 1500,
  "tributes": 1
 },
 {
  "id": 21,
  "name": "Serpent of Echoes",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/21-serpent-of-echoes.jpg",
  "level": 5,
  "atk": 1800,
  "def": 1400,
  "tributes": 1
 },
 {
  "id": 22,
  "name": "Rust Maw",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/22-rust-maw.jpg",
  "level": 6,
  "atk": 1900,
  "def": 1800,
  "tributes": 1
 },
 {
  "id": 23,
  "name": "Grave Blossom",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/23-grave-blossom.jpg",
  "level": 6,
  "atk": 2000,
  "def": 1700,
  "tributes": 1
 },
 {
  "id": 24,
  "name": "Mirror Specter",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/24-mirror-specter.jpg",
  "level": 6,
  "atk": 2000,
  "def": 1800,
  "tributes": 1
 },
 {
  "id": 25,
  "name": "Rift Revenant",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/25-rift-revenant.jpg",
  "level": 6,
  "atk": 2100,
  "def": 1700,
  "tributes": 1
 },
 {
  "id": 26,
  "name": "Aeon Turtle",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/26-aeon-turtle.jpg",
  "level": 6,
  "atk": 2100,
  "def": 2000,
  "tributes": 1
 },
 {
  "id": 27,
  "name": "Chain Wraith",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/27-chain-wraith.jpg",
  "level": 6,
  "atk": 2100,
  "def": 2000,
  "tributes": 1
 },
 {
  "id": 28,
  "name": "Solar Judge",
  "type": "monster",
  "rarity": "rare",
  "img": "assets/images/cards/monsters/28-solar-judge.jpg",
  "level": 6,
  "atk": 2200,
  "def": 1900,
  "tributes": 1
 },
 {
  "id": 29,
  "name": "Lunar Disciple",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/29-lunar-disciple.jpg",
  "level": 7,
  "atk": 2300,
  "def": 2000,
  "tributes": 2
 },
 {
  "id": 30,
  "name": "Obsidian Golem",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/30-obsidian-golem.jpg",
  "level": 7,
  "atk": 2300,
  "def": 2100,
  "tributes": 2
 },
 {
  "id": 31,
  "name": "Eternity Dragon",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/31-eternity-dragon.jpg",
  "level": 7,
  "atk": 2400,
  "def": 2000,
  "tributes": 2
 },
 {
  "id": 32,
  "name": "Fallen Sanctum",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/32-fallen-sanctum.jpg",
  "level": 7,
  "atk": 2400,
  "def": 2200,
  "tributes": 2
 },
 {
  "id": 33,
  "name": "Harbinger Knight",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/33-harbinger-knight.jpg",
  "level": 7,
  "atk": 2500,
  "def": 2200,
  "tributes": 2
 },
 {
  "id": 34,
  "name": "Plague Swarm",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/34-plague-swarm.jpg",
  "level": 7,
  "atk": 2600,
  "def": 2400,
  "tributes": 2
 },
 {
  "id": 35,
  "name": "Silence Siren",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/35-silence-siren.jpg",
  "level": 7,
  "atk": 2600,
  "def": 2400,
  "tributes": 2
 },
 {
  "id": 36,
  "name": "Blood Moon Beast",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/36-blood-moon-beast.jpg",
  "level": 7,
  "atk": 2700,
  "def": 2300,
  "tributes": 2
 },
 {
  "id": 37,
  "name": "Tempest Colossus",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/37-tempest-colossus.jpg",
  "level": 7,
  "atk": 2700,
  "def": 2500,
  "tributes": 2
 },
 {
  "id": 38,
  "name": "Veil Prophet",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/38-veil-prophet.jpg",
  "level": 7,
  "atk": 2800,
  "def": 2500,
  "tributes": 2
 },
 {
  "id": 39,
  "name": "Ruin Devourer",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/39-ruin-devourer.jpg",
  "level": 7,
  "atk": 2800,
  "def": 2600,
  "tributes": 2
 },
 {
  "id": 40,
  "name": "Starfall Entity",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/40-starfall-entity.jpg",
  "level": 8,
  "atk": 2900,
  "def": 2600,
  "tributes": 2
 },
 {
  "id": 41,
  "name": "Nether Aphorix",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/41-nether-aphorix.jpg",
  "level": 8,
  "atk": 3000,
  "def": 2500,
  "tributes": 2
 },
 {
  "id": 42,
  "name": "Kael, Bearer of Echoes",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/42-kael-bearer-of-echoes.jpg",
  "level": 8,
  "atk": 3000,
  "def": 2700,
  "tributes": 2
 },
 {
  "id": 43,
  "name": "The Watcher",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/43-the-watcher.jpg",
  "level": 8,
  "atk": 3200,
  "def": 2800,
  "tributes": 2
 },
 {
  "id": 44,
  "name": "Echoveil Sovereign",
  "type": "monster",
  "rarity": "mythic",
  "img": "assets/images/cards/monsters/44-echoveil-sovereign.jpg",
  "level": 8,
  "atk": 3500,
  "def": 3000,
  "tributes": 2
 },
 {
  "id": 45,
  "name": "Echo of Life",
  "type": "miracle",
  "rarity": "uncommon",
  "img": "assets/images/cards/miracles/45-echo-of-life.jpg",
  "text": "Restore 1000 LP to you."
 },
 {
  "id": 46,
  "name": "Radiant Prayer",
  "type": "miracle",
  "rarity": "uncommon",
  "img": "assets/images/cards/miracles/46-radiant-prayer.jpg",
  "text": "Your monsters gain 800 ATK this turn."
 },
 {
  "id": 47,
  "name": "Veil of Protection",
  "type": "miracle",
  "rarity": "uncommon",
  "img": "assets/images/cards/miracles/47-veil-of-protection.jpg",
  "text": "Your monsters gain 500 DEF permanently."
 },
 {
  "id": 48,
  "name": "Soul Resonance",
  "type": "miracle",
  "rarity": "rare",
  "img": "assets/images/cards/miracles/48-soul-resonance.jpg",
  "text": "Draw 2 cards."
 },
 {
  "id": 49,
  "name": "Celestial Guidance",
  "type": "miracle",
  "rarity": "rare",
  "img": "assets/images/cards/miracles/49-celestial-guidance.jpg",
  "text": "Draw 1 card."
 },
 {
  "id": 50,
  "name": "Purifying Light",
  "type": "miracle",
  "rarity": "uncommon",
  "img": "assets/images/cards/miracles/50-purifying-light.jpg",
  "text": "Destroy 1 random opponent monster."
 },
 {
  "id": 51,
  "name": "Eternal Bloom",
  "type": "miracle",
  "rarity": "mythic",
  "img": "assets/images/cards/miracles/51-eternal-bloom.jpg",
  "text": "Special Summon your last destroyed Monster."
 },
 {
  "id": 52,
  "name": "Storm of Echoes",
  "type": "miracle",
  "rarity": "mythic",
  "img": "assets/images/cards/miracles/52-storm-of-echoes.jpg",
  "text": "Destroy all opponent monsters."
 },
 {
  "id": 53,
  "name": "Fragments of Memory",
  "type": "miracle",
  "rarity": "uncommon",
  "img": "assets/images/cards/miracles/53-fragments-of-memory.jpg",
  "text": "Add the last card of your Graveyard to your hand."
 },
 {
  "id": 54,
  "name": "Divine Balance",
  "type": "miracle",
  "rarity": "rare",
  "img": "assets/images/cards/miracles/54-divine-balance.jpg",
  "text": "The player with fewer cards in hand draws until both are equal."
 },
 {
  "id": 55,
  "name": "Ascension",
  "type": "miracle",
  "rarity": "mythic",
  "img": "assets/images/cards/miracles/55-ascension.jpg",
  "text": "Tribute your weakest Monster, then Special Summon the highest Level Monster from your hand."
 },
 {
  "id": 56,
  "name": "Healing Rain",
  "type": "miracle",
  "rarity": "uncommon",
  "img": "assets/images/cards/miracles/56-healing-rain.jpg",
  "text": "Restore 2000 LP to you."
 },
 {
  "id": 57,
  "name": "Time Reversal",
  "type": "miracle",
  "rarity": "rare",
  "img": "assets/images/cards/miracles/57-time-reversal.jpg",
  "text": "Return the opponent’s strongest Monster to their hand."
 },
 {
  "id": 58,
  "name": "Veil Break",
  "type": "miracle",
  "rarity": "mythic",
  "img": "assets/images/cards/miracles/58-veil-break.jpg",
  "text": "Destroy the opponent’s strongest Monster."
 },
 {
  "id": 59,
  "name": "Echoing Fury",
  "type": "miracle",
  "rarity": "rare",
  "img": "assets/images/cards/miracles/59-echoing-fury.jpg",
  "text": "Double the ATK of your strongest Monster this turn."
 },
 {
  "id": 60,
  "name": "Last Sanctuary",
  "type": "miracle",
  "rarity": "mythic",
  "img": "assets/images/cards/miracles/60-last-sanctuary.jpg",
  "text": "Prevent all damage you would take until your next turn."
 },
 {
  "id": 61,
  "name": "Soul Exchange",
  "type": "miracle",
  "rarity": "mythic",
  "img": "assets/images/cards/miracles/61-soul-exchange.jpg",
  "text": "Take control of the opponent’s strongest Monster until end of turn."
 },
 {
  "id": 62,
  "name": "New Dawn",
  "type": "miracle",
  "rarity": "rare",
  "img": "assets/images/cards/miracles/62-new-dawn.jpg",
  "text": "Draw cards equal to the Monsters in your Graveyard (max 3)."
 },
 {
  "id": 63,
  "name": "Chains of Supression",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/63-chains-of-supression.jpg",
  "text": "When the opponent summons: that Monster cannot attack this turn.",
  "trigger": "summon"
 },
 {
  "id": 64,
  "name": "Mirror Reversal",
  "type": "trap",
  "rarity": "mythic",
  "img": "assets/images/cards/traps/64-mirror-reversal.jpg",
  "text": "When the opponent activates a Miracle: negate it and use its effect for yourself.",
  "trigger": "spell"
 },
 {
  "id": 65,
  "name": "Void Snare",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/65-void-snare.jpg",
  "text": "When the opponent attacks: banish the attacker.",
  "trigger": "attack"
 },
 {
  "id": 66,
  "name": "Crimson Judgment",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/66-crimson-judgment.jpg",
  "text": "When the opponent attacks: destroy their strongest Monster.",
  "trigger": "attack"
 },
 {
  "id": 67,
  "name": "Veil of Silence",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/67-veil-of-silence.jpg",
  "text": "When the opponent activates a Miracle: negate it.",
  "trigger": "spell"
 },
 {
  "id": 68,
  "name": "Shattered Reality",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/68-shattered-reality.jpg",
  "text": "When the opponent activates a Miracle: negate it and destroy it.",
  "trigger": "spell"
 },
 {
  "id": 69,
  "name": "Echoing Curse",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/69-echoing-curse.jpg",
  "text": "When the opponent activates a Miracle: inflict 500 damage to them.",
  "trigger": "spell"
 },
 {
  "id": 70,
  "name": "Last Stand",
  "type": "trap",
  "rarity": "mythic",
  "img": "assets/images/cards/traps/70-last-stand.jpg",
  "text": "When your LP would drop to 0: stay at 1 LP instead.",
  "trigger": "lp0"
 },
 {
  "id": 71,
  "name": "Doomed Return",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/71-doomed-return.jpg",
  "text": "When the opponent attacks: Special Summon your last destroyed Monster.",
  "trigger": "attack"
 },
 {
  "id": 72,
  "name": "Abyssal Prison",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/72-abyssal-prison.jpg",
  "text": "When the opponent summons: banish that Monster.",
  "trigger": "summon"
 },
 {
  "id": 73,
  "name": "Blood Oath",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/73-blood-oath.jpg",
  "text": "When you take damage: draw 1 card.",
  "trigger": "damage"
 },
 {
  "id": 74,
  "name": "Veil of Decay",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/74-veil-of-decay.jpg",
  "text": "When the opponent attacks: reduce the attacker’s ATK by 800.",
  "trigger": "attack"
 },
 {
  "id": 75,
  "name": "Fallen Sanctum",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/75-fallen-sanctum.jpg",
  "text": "When the opponent activates a Miracle: destroy it.",
  "trigger": "spell"
 },
 {
  "id": 76,
  "name": "Soul Drain",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/76-soul-drain.jpg",
  "text": "When the opponent summons: negate and destroy that Monster.",
  "trigger": "summon"
 },
 {
  "id": 77,
  "name": "Broken Cycle",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/77-broken-cycle.jpg",
  "text": "When the opponent attacks: negate it. Their Monsters cannot attack again this turn.",
  "trigger": "attack"
 },
 {
  "id": 78,
  "name": "Eternal Shackles",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/78-eternal-shackles.jpg",
  "text": "When the opponent summons: their Monsters cannot attack this turn.",
  "trigger": "summon"
 },
 {
  "id": 79,
  "name": "Chaos Reflection",
  "type": "trap",
  "rarity": "uncommon",
  "img": "assets/images/cards/traps/79-chaos-reflection.jpg",
  "text": "When the opponent summons: return that Monster to their hand.",
  "trigger": "summon"
 },
 {
  "id": 80,
  "name": "Oblivion Gate",
  "type": "trap",
  "rarity": "rare",
  "img": "assets/images/cards/traps/80-oblivion-gate.jpg",
  "text": "When the opponent attacks: destroy their strongest Monster.",
  "trigger": "attack"
 }
];
