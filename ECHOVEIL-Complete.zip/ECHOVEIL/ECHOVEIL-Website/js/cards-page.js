(()=>{'use strict';
const ALL=window.ECHOVEIL_CARDS||[],LORE=window.ECHOVEIL_LORE||{};const $=s=>document.querySelector(s);
const grid=$('#cgrid'),cnt=$('#count'),q=$('#q'),chips=[...document.querySelectorAll('.chip[data-t]')],rchips=[...document.querySelectorAll('.chip[data-r]')],modal=$('#cmodal');
let type='all',rar='all',list=[],cur=-1;const params=new URLSearchParams(location.search);
const T={monster:'Monster',miracle:'Miracle',trap:'Trap'},RN={common:'Common',uncommon:'Uncommon',rare:'Rare',mythic:'Mythic'},TI={common:0,uncommon:1,rare:2,mythic:3};
const trig={attack:'Opponent attacks',summon:'Opponent summons',spell:'Opponent activates a Miracle',damage:'You take damage',lp0:'Your LP would reach 0'};
const KL={unknown:'Origin unknown',disputed:'Disputed'};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const byId=Object.fromEntries(ALL.map(c=>[c.id,c]));
/* lore connections are symmetrical: A lists B, or B lists A */
const REL={};(window.ECHOVEIL_LINKS||[]).forEach(([a,b,w])=>{if(byId[a]&&byId[b]){(REL[a]=REL[a]||[]).push({id:b,w});(REL[b]=REL[b]||[]).push({id:a,w})}});
try{const s=JSON.parse(sessionStorage.getItem('ev-cards')||'{}');if(s.type)type=s.type;if(s.rar)rar=s.rar;if(s.q)q.value=s.q}catch(e){}
const save=()=>{try{sessionStorage.setItem('ev-cards',JSON.stringify({type,rar,q:q.value}))}catch(e){}};
const pressed=()=>{chips.forEach(x=>x.setAttribute('aria-pressed',x.dataset.t===type));rchips.forEach(x=>x.setAttribute('aria-pressed',x.dataset.r===rar))};
const img=(c,cls)=>`<img${cls?` class="${cls}"`:''} src="${IMGS(c.img)}" alt="${esc(c.name)} card artwork" decoding="async">`;
function render(){const s=q.value.trim().toLowerCase();save();pressed();
 list=ALL.filter(c=>(type==='all'||c.type===type)&&(rar==='all'||c.rarity===rar)&&(!s||c.name.toLowerCase().includes(s)||((LORE[c.id]||{}).e||'').toLowerCase().includes(s)));
 cnt.textContent=`${list.length} of ${ALL.length} cards`;
 grid.innerHTML=list.length?list.map((c,i)=>`<button class="c ${c.type==='monster'?'m':'x'} t-${c.type} r${TI[c.rarity]}" data-i="${i}" aria-label="${esc(c.name)}, ${RN[c.rarity]} ${T[c.type]} card"><span class="art"><img src="${IMGS(c.img)}" alt="${esc(c.name)} card artwork" loading="${i<14?'eager':'lazy'}" decoding="async"></span><span class="nm">${esc(c.name)}</span><span class="tag">${RN[c.rarity]} · ${T[c.type]}</span></button>`).join(''):'<p class="empty">No cards match your search.</p>'}
/* graceful fallback for missing images */
document.addEventListener('error',e=>{const t=e.target;if(t.tagName==='IMG'&&t.closest('#cgrid,#cmodal')&&!t.dataset.f){t.dataset.f=1;const f=document.createElement('span');f.className='fallback';f.textContent=t.alt.replace(' card artwork','');t.replaceWith(f)}},true);
function open(i,keep){cur=i;const c=list[i];if(!c)return;const L=LORE[c.id]||{},isM=c.type==='monster';
 const st=isM?`<dt>Level</dt><dd>${c.level}</dd><dt>ATK / DEF</dt><dd>${c.atk} / ${c.def}</dd><dt>Tributes</dt><dd>${c.tributes?c.tributes+' required':'None required'}</dd>`:`<dt>Effect</dt><dd>${esc(c.text||'')}</dd>${c.trigger&&trig[c.trigger]?`<dt>Trigger</dt><dd>${trig[c.trigger]}</dd>`:''}`;
 const rel=(REL[c.id]||[]).map(x=>({c:byId[x.id],w:x.w}));
 $('#mbody').innerHTML=`<figure class="fig t-${c.type} r${TI[c.rarity]} ${isM?'m':'x'}"><button class="zoomb" aria-label="Toggle enlarged artwork" title="Click to enlarge">${img(c,'big')}<span class="zh" aria-hidden="true">⤢</span></button></figure>
<div class="info"><span class="kind ${c.type}">${T[c.type]} card</span><h3 id="mtitle">${esc(c.name)}</h3>${L.e?`<p class="epi">${esc(L.e)}</p>`:''}
<p class="badges"><span class="rb r${TI[c.rarity]}">${RN[c.rarity]}</span>${L.k?`<span class="badge planned">${KL[L.k]}</span>`:''}</p>
<dl class="stats"><dt>No.</dt><dd>${String(c.id).padStart(2,'0')} / ${ALL.length}</dd>${st}</dl>
${L.c?`<section class="lore"><h4>Chronicle</h4>${L.o?`<p class="orig"><b>Origin:</b> ${esc(L.o)}</p>`:''}<p>${esc(L.c)}</p>
${L.i?`<blockquote>“${esc(L.i)}”<cite>Ancient inscription</cite></blockquote>`:''}
${L.s?`<p class="secret"><b>Unresolved:</b> ${esc(L.s)}</p>`:''}
${rel.length?`<h4>Connections</h4><ul class="rels">${rel.map(r=>`<li><button class="relbtn" data-id="${r.c.id}">${esc(r.c.name)}<small>${T[r.c.type]}</small></button><span>${esc(r.w)}</span></li>`).join('')}</ul>`:''}
${L.n?`<p class="canon"><b>Confirmed canon.</b> ${esc(L.n.replace(/^Established:\s*/,''))}</p>`:''}
<p class="note">Lore status: <b>Proposed</b>, new writing awaiting the creator’s approval${L.n?', except where marked confirmed':''}. Stats and effects come directly from the game.</p></section>`:''}</div>`;
 const mb=$('#mbody');mb.classList.remove('zoomed');mb.scrollTop=0;modal.scrollTop=0;
 if(!modal.classList.contains('on'))EV.modal(modal)}
grid.addEventListener('click',e=>{const b=e.target.closest('.c');if(b)open(+b.dataset.i)});
$('#mbody').addEventListener('click',e=>{if(e.target.closest('.zoomb')){$('#mbody').classList.toggle('zoomed');return}const b=e.target.closest('.relbtn');if(!b)return;const id=+b.dataset.id;let i=list.findIndex(c=>c.id===id);
 if(i<0){/* related card hidden by the current filter: show it without losing the filter */list=list.concat(byId[id]);i=list.length-1}open(i)});
const step=d=>open((cur+d+list.length)%list.length);
$('#mprev').onclick=()=>step(-1);$('#mnext').onclick=()=>step(1);
modal.addEventListener('closed',()=>render());
addEventListener('keydown',e=>{if(!modal.classList.contains('on'))return;if(e.key==='ArrowLeft')step(-1);if(e.key==='ArrowRight')step(1)});
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches,colh=document.getElementById('colh');
const toGrid=()=>{if(colh&&colh.getBoundingClientRect().top>innerHeight*.6)colh.scrollIntoView({behavior:RM?'auto':'smooth',block:'start'})};
chips.forEach(b=>b.onclick=()=>{type=b.dataset.t;render();toGrid()});rchips.forEach(b=>b.onclick=()=>{rar=b.dataset.r;render()});
q.oninput=()=>{render();toGrid()};
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{type=b.dataset.go;render();colh&&colh.scrollIntoView({behavior:RM?'auto':'smooth',block:'start'})});
const fsc=document.getElementById('fscroll');
if(fsc){fsc.addEventListener('click',e=>{const b=e.target.closest('.fc');if(!b)return;type='all';rar='all';q.value='';render();const i=list.findIndex(c=>c.id===+b.dataset.id);i>=0&&open(i)});
 document.getElementById('fl').onclick=()=>fsc.scrollBy({left:-420,behavior:RM?'auto':'smooth'});document.getElementById('fr').onclick=()=>fsc.scrollBy({left:420,behavior:RM?'auto':'smooth'})}
const pt=params.get('type');if(pt&&['monster','miracle','trap'].includes(pt))type=pt;
render();const pid=+params.get('card');if(pid){type='all';rar='all';q.value='';render();const i=list.findIndex(c=>c.id===pid);i>=0&&open(i)}
addEventListener('ev-cards',e=>{const d=e.detail||{};if(d.card){type='all';rar='all';q.value=''}if(d.type){type=d.type;chips.forEach(x=>x.setAttribute('aria-pressed',x.dataset.t===d.type))}render();if(d.card){const i=list.findIndex(c=>c.id===+d.card);i>=0&&open(i)}});
})();
