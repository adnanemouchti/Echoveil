/* ECHOVEIL site configuration. Fill these in ONLY with real links. Empty values keep the related buttons disabled / hidden. */
window.ECHOVEIL_CONFIG = {
  supportUrl: "",     // e.g. your Ko-fi / Patreon / itch.io donation page
  wishlistUrl: "",    // e.g. Steam wishlist page, if the game is ever listed
  platforms: [],      // e.g. [{ name: "itch.io", url: "https://..." }]
  socials: { Discord: "", YouTube: "", X: "" },   // footer links appear only when filled
  contactEmail: ""    // optional
};
