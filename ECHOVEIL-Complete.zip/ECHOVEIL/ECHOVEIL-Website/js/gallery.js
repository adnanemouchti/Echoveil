(()=>{'use strict';
const IM=typeof IMGS==='function'?IMGS:(p=>p);const C=window.ECHOVEIL_CARDS||[];const by=n=>C.find(c=>c.name===n);
const mk=(src,cap,cat,alt,w,h)=>({src,cap,cat,alt,w,h});
const card=(n,cat)=>{const c=by(n);return mk(c.img,c.name+' · '+c.type+' card',cat,c.name+' card artwork',c.type==='monster'?130:245,c.type==='monster'?220:295)};
const G='assets/images/gameplay/',B='assets/images/backgrounds/',K='assets/images/concept/';
const HIGH=[
 mk(B+'hero-citadel.jpg','Title artwork · detail','artwork environments','A dark citadel on a cliff beneath a violet vortex, waterfalls falling into mist',882,941),
 mk(G+'duel-board.jpg','Real gameplay: a duel against The Watcher','gameplay','A real ECHOVEIL duel with a Monster summoned and a card set',1572,785),
 mk(B+'citadel-wide.jpg','The floating citadel','environments','Gothic citadel with waterfalls under a violet sky',770,460),
 mk(K+'gallery-hooded.jpg','Hooded figure · concept art','artwork','A hooded figure with glowing violet eyes',588,334),
 card('Kael, Bearer of Echoes','cards artwork'),
 mk(G+'menu.jpg','Main menu','ui','The ECHOVEIL main menu',1600,900),
 mk(G+'challenge.jpg','Choose your challenge','ui gameplay','The Choose Your Challenge screen',1600,900),
 mk(G+'deck-builder.jpg','Deck & Cards screen','ui gameplay','The Deck and Cards screen',1600,900),
 mk(B+'candlelit-table.jpg','Candlelit table','environments','Candles, a sword and card backs on an ancient table',1152,381),
 mk(G+'duel-start.jpg','Real gameplay: the opening of a duel','gameplay','The start of a duel against The Watcher',1572,785),
 card('The Watcher','cards artwork'),card('Echoveil Sovereign','cards artwork'),card('Eternity Dragon','cards artwork'),
 mk(B+'battlefield-1.jpg','Battlefield backdrop (in-game art)','environments ui','Empty battlefield with an eclipse above the board',1600,985),
 mk(B+'battlefield-2.jpg','Battlefield backdrop, wide variant','environments ui','Wide variant of the battlefield backdrop',1600,727),
 mk(B+'echoes-vortex.jpg','The Eclipse Gate · detail','artwork environments','A violet vortex in the night sky',540,360),
 mk(K+'lore-ruins.jpg','Ruins · concept art','environments artwork','Ruined towers lit by faint light',474,320)];
const ALLC=C.map(c=>({...card(c.name,'cards'),cat:'cards'}));
const mason=document.getElementById('mason'),chips=[...document.querySelectorAll('.chip[data-f]')],lb=document.getElementById('lb');
let list=[],cur=0,f='all';
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function render(){list=f==='all'?HIGH.slice(0,9):f==='cards'?ALLC:HIGH.filter(i=>i.cat.split(' ').includes(f));
 mason.className='mosaic'+(f==='cards'?' cardsonly':'');
 mason.innerHTML=list.map((i,k)=>`<button class="gi${i.cat.includes('cards')?' card':''}" data-k="${k}" aria-label="Enlarge: ${esc(i.cap)}"><span class="frame"><img src="${IM(i.src)}" alt="${esc(i.alt)}" width="${i.w}" height="${i.h}" loading="${k<4?'eager':'lazy'}" decoding="async"></span><span class="cap">${esc(i.cap)}</span></button>`).join('')}
function show(k){cur=(k+list.length)%list.length;const i=list[cur];document.getElementById('lbimg').src=IM(i.src);document.getElementById('lbimg').alt=i.alt;document.getElementById('lbcap').textContent=i.cap;if(!lb.classList.contains('on'))EV.modal(lb)}
mason.onclick=e=>{const b=e.target.closest('.gi');b&&show(+b.dataset.k)};
document.getElementById('lbp').onclick=()=>show(cur-1);document.getElementById('lbn').onclick=()=>show(cur+1);
addEventListener('keydown',e=>{if(!lb.classList.contains('on'))return;if(e.key==='ArrowLeft')show(cur-1);if(e.key==='ArrowRight')show(cur+1)});
chips.forEach(b=>b.onclick=()=>{f=b.dataset.f;chips.forEach(x=>x.setAttribute('aria-pressed',x===b));render()});
render()})();
