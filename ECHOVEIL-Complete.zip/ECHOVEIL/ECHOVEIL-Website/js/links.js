(()=>{'use strict';
const c=window.ECHOVEIL_CONFIG||{};
const wire=(id,url)=>{const a=document.getElementById(id);if(!a)return;const note=document.getElementById(id+'-note');
 if(url){a.href=url;a.target='_blank';a.rel='noopener';a.removeAttribute('aria-disabled');if(note)note.hidden=true}
 else{a.removeAttribute('href');a.setAttribute('aria-disabled','true');a.addEventListener('click',e=>{e.preventDefault();if(note)note.hidden=false})}};
wire('support',c.supportUrl);wire('wishlist',c.wishlistUrl);
const fo=document.getElementById('follow');const so=Object.entries(c.socials||{}).filter(([,u])=>u);if(fo&&so.length){fo.hidden=false;fo.innerHTML='Follow us: '+so.map(([k,u])=>`<a href="${u}" target="_blank" rel="noopener">${k}</a>`).join(' ')}
const pl=document.getElementById('platforms');
if(pl&&(c.platforms||[]).length){pl.innerHTML=c.platforms.map(p=>`<li><a class="btn alt mini" href="${p.url}" target="_blank" rel="noopener">${p.name}</a></li>`).join('');pl.hidden=false;document.getElementById('noplat').hidden=true}})();
