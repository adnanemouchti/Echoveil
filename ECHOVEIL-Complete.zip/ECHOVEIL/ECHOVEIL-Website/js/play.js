(()=>{'use strict';
/* Play page controller. The game itself lives in /game/ and is loaded in an iframe only after the player clicks Play. */
const GAME_URL='game/index.html',TIMEOUT=25000;
const $=id=>document.getElementById(id),stage=$('stage'),cover=$('cover'),loading=$('loading'),err=$('error'),errMsg=$('errmsg');
let frame=null,timer=null;
function fail(m){clearTimeout(timer);loading.hidden=true;cover.hidden=true;err.hidden=false;errMsg.textContent=m;if(frame){frame.remove();frame=null}}
function start(){err.hidden=true;cover.hidden=true;loading.hidden=false;if(frame)frame.remove();
 frame=document.createElement('iframe');frame.title='ECHOVEIL game';frame.allow='fullscreen; autoplay';frame.setAttribute('allowfullscreen','');
 frame.addEventListener('load',()=>{clearTimeout(timer);
  try{const d=frame.contentDocument;if(d&&!d.getElementById('menu')){return fail('The game file loaded, but it does not look like the ECHOVEIL game. Check that game/index.html is the correct build.')}}catch(e){/* cross-origin / file:// — assume OK */}
  loading.hidden=true;frame.focus()});
 frame.addEventListener('error',()=>fail('The game file could not be loaded.'));
 timer=setTimeout(()=>fail('The game is taking too long to load. Check your connection and try again.'),TIMEOUT);
 frame.src=GAME_URL;stage.appendChild(frame)}
function fs(){if(document.fullscreenElement){document.exitFullscreen()}else if(stage.requestFullscreen){stage.requestFullscreen().catch(()=>{})}else{$('fsnote').hidden=false}}
$('ctl').onclick=()=>EV.modal(document.getElementById('controls'));$('play').onclick=start;$('retry').onclick=start;$('fs').onclick=fs;
$('reload').onclick=()=>{if(confirm('Reset the game window? Your saved progress is kept, but the current duel will be lost.'))start()};
document.addEventListener('fullscreenchange',()=>{$('fs').lastElementChild.textContent=document.fullscreenElement?'Exit Fullscreen':'Fullscreen'});
})();
