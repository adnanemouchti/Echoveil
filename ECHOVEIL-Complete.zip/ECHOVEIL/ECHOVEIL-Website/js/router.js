const PAGES=["home", "the-game", "cards", "lore", "gallery", "play", "store"];let pend=null;
function routeNow(){let h=location.hash.slice(1);const cur=document.querySelector('[data-page]:not([hidden])');
 if(!PAGES.includes(h)){if(cur)return;h='home'}
 if(!cur||cur.dataset.page!==h){document.querySelectorAll('[data-page]').forEach(p=>p.hidden=p.dataset.page!==h);scrollTo(0,0);dispatchEvent(new Event('resize'))}
 const p=document.querySelector('[data-page="'+h+'"]');document.title=p.dataset.title;
 document.querySelectorAll('#nav a,.wish').forEach(a=>a.getAttribute('href')==='#'+h?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current'));
 if(pend){const d=pend;pend=null;dispatchEvent(new CustomEvent('ev-cards',{detail:d}))}}
addEventListener('hashchange',routeNow);
document.addEventListener('click',e=>{const a=e.target.closest('a[data-card],a[data-type]');if(!a)return;pend={card:a.dataset.card,type:a.dataset.type};const t=a.getAttribute('href');if(location.hash===t){e.preventDefault();routeNow()}});
routeNow();
