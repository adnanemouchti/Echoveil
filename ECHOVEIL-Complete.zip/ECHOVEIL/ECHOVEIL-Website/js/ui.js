(()=>{'use strict';
document.documentElement.classList.add('js');
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
/* config-driven footer socials: only genuine links from config.js are shown */
const cfg=window.ECHOVEIL_CONFIG||{};
const soc=document.getElementById('socials');
if(soc){const e=Object.entries(cfg.socials||{}).filter(([,u])=>u);
 if(e.length){soc.innerHTML=e.map(([k,u])=>`<li><a href="${u}" rel="noopener" target="_blank">${k}</a></li>`).join('')}
 else{soc.innerHTML='<li><a href="#store">Wishlist &amp; support</a></li><li class="muted fnote">Community channels have not been announced yet.</li>'}}
/* mobile nav */
const b=document.querySelector('.burger'),n=document.getElementById('nav');
if(b&&n){const set=o=>{n.classList.toggle('open',o);b.setAttribute('aria-expanded',o)};
 b.onclick=()=>set(!n.classList.contains('open'));
 n.addEventListener('click',e=>{if(e.target.closest('a'))set(false)});
 addEventListener('keydown',e=>{if(e.key==='Escape')set(false)})}
/* reveal on scroll */
const rv=[...document.querySelectorAll('.rv')];
if('IntersectionObserver' in window&&!RM){const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.12});rv.forEach(e=>io.observe(e))}else rv.forEach(e=>e.classList.add('in'));
/* hero: particles + gentle parallax */
const cv=document.getElementById('fx');
if(cv&&!RM){const x=cv.getContext('2d');let w,h,P=[],on=true;
 const rs=()=>{w=cv.width=cv.offsetWidth;h=cv.height=cv.offsetHeight};rs();addEventListener('resize',rs);
 const N=innerWidth<700?28:60;for(let i=0;i<N;i++)P.push({x:Math.random(),y:Math.random(),s:Math.random()*1.8+.4,v:Math.random()*.0004+.00012,g:Math.random()<.35});
 new IntersectionObserver(e=>on=e[0].isIntersecting).observe(cv);
 (function f(){if(on){x.clearRect(0,0,w,h);for(const p of P){p.y-=p.v;p.x+=Math.sin(p.y*18+p.s)*.0003;if(p.y<0){p.y=1;p.x=Math.random()}
  x.fillStyle=p.g?'rgba(234,211,160,.75)':'rgba(190,150,255,.65)';x.shadowBlur=8;x.shadowColor=p.g?'#C7A46A':'#9b6bff';x.beginPath();x.arc(p.x*w,p.y*h,p.s,0,6.3);x.fill()}}requestAnimationFrame(f)})();
 const art=document.querySelector('.hart>img');
 if(art&&matchMedia('(pointer:fine)').matches)addEventListener('mousemove',e=>{const dx=(e.clientX/innerWidth-.5)*-14,dy=(e.clientY/innerHeight-.5)*-10;art.style.transform=`scale(1.06) translate(${dx}px,${dy}px)`},{passive:true})}
document.addEventListener('click',e=>{const o=e.target.closest('[data-open]');if(o){const m=document.getElementById(o.dataset.open);m&&EV.modal(m)}});
/* tabs */
document.querySelectorAll('[role=tablist]').forEach(l=>{const t=[...l.querySelectorAll('[role=tab]')];
 const sel=x=>t.forEach(y=>{const o=y===x;y.setAttribute('aria-selected',o);y.setAttribute('aria-pressed',o);document.getElementById(y.getAttribute('aria-controls')).hidden=!o});
 t.forEach(x=>x.onclick=()=>sel(x))});
/* generic modal helper */
window.EV={modal(el){const prev=document.activeElement;el.classList.add('on');document.body.style.overflow='hidden';(el.querySelector('[data-close]')||el).focus();
 const close=()=>{el.classList.remove('on');document.body.style.overflow='';prev&&prev.focus&&prev.focus();el.dispatchEvent(new Event('closed'))};
 el.querySelectorAll('[data-close]').forEach(c=>c.onclick=close);el.onclick=e=>{if(e.target===el)close()};
 el.onkeydown=e=>{if(e.key!=='Tab')return;const f=[...el.querySelectorAll('button:not([disabled])')].filter(x=>x.offsetParent!==null||getComputedStyle(x).position==='fixed');if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}};el._close=close;return close},
 card:c=>c};
addEventListener('keydown',e=>{if(e.key==='Escape'){const m=document.querySelector('.modal.on');m&&m._close&&m._close()}});
})();
