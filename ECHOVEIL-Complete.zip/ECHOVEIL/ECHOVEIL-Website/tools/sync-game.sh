#!/usr/bin/env sh
# Refresh the website's game/ folder from the separate game project.
# Run from the ECHOVEIL/ folder:  sh ECHOVEIL-Website/tools/sync-game.sh
set -e
SRC="ECHOVEIL-Game"; DST="ECHOVEIL-Website/game"
[ -d "$SRC" ] || { echo "Run this from the folder that contains $SRC"; exit 1; }
rm -rf "$DST" && mkdir -p "$DST"
cp -R "$SRC/index.html" "$SRC/css" "$SRC/js" "$SRC/assets" "$DST/"
echo "Copied $SRC -> $DST"
